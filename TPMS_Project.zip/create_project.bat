@echo off
mkdir .github\workflows app\src\main\java\com\example\tpmsapp app\src\main\res\layout app\src\main\res\values app\src\main\res\drawable app\src\main\res\xml

echo name: Build APK > .github\workflows\build.yml
echo on: [push] >> .github\workflows\build.yml
echo jobs: >> .github\workflows\build.yml
echo   build: >> .github\workflows\build.yml
echo     runs-on: ubuntu-latest >> .github\workflows\build.yml
echo     steps: >> .github\workflows\build.yml
echo     - uses: actions/checkout@v3 >> .github\workflows\build.yml
echo     - name: Set up JDK 17 >> .github\workflows\build.yml
echo       uses: actions/setup-java@v3 >> .github\workflows\build.yml
echo       with: >> .github\workflows\build.yml
echo         java-version: '17' >> .github\workflows\build.yml
echo         distribution: 'temurin' >> .github\workflows\build.yml
echo     - name: Setup Gradle >> .github\workflows\build.yml
echo       uses: gradle/gradle-build-action@v2 >> .github\workflows\build.yml
echo     - name: Make gradlew executable >> .github\workflows\build.yml
echo       run: chmod +x gradlew >> .github\workflows\build.yml
echo     - name: Build Debug APK >> .github\workflows\build.yml
echo       run: ./gradlew assembleDebug >> .github\workflows\build.yml
echo     - name: Upload APK >> .github\workflows\build.yml
echo       uses: actions/upload-artifact@v3 >> .github\workflows\build.yml
echo       with: >> .github\workflows\build.yml
echo         name: TPMS-App >> .github\workflows\build.yml
echo         path: app/build/outputs/apk/debug/app-debug.apk >> .github\workflows\build.yml

echo pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } } > settings.gradle
echo dependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); repositories { google(); mavenCentral(); maven { url 'https://jitpack.io' } } } >> settings.gradle
echo rootProject.name = "TPMSApp" >> settings.gradle
echo include ':app' >> settings.gradle

echo org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8 > gradle.properties
echo android.useAndroidX=true >> gradle.properties
echo android.nonTransitiveRClass=true >> gradle.properties

echo plugins { id 'com.android.application'; id 'org.jetbrains.kotlin.android' } > app\build.gradle
echo android { namespace 'com.example.tpmsapp'; compileSdk 34 >> app\build.gradle
echo defaultConfig { applicationId "com.example.tpmsapp"; minSdk 21; targetSdk 34; versionCode 1; versionName "1.0" } >> app\build.gradle
echo compileOptions { sourceCompatibility JavaVersion.VERSION_17; targetCompatibility JavaVersion.VERSION_17 } >> app\build.gradle
echo kotlinOptions { jvmTarget = '17' } } >> app\build.gradle
echo dependencies { implementation 'androidx.core:core-ktx:1.12.0'; implementation 'androidx.appcompat:appcompat:1.6.1'; implementation 'com.google.android.material:material:1.11.0'; implementation 'com.github.mik3y:usb-serial-for-android:3.5.2' } >> app\build.gradle

echo Project structure created successfully!
pause